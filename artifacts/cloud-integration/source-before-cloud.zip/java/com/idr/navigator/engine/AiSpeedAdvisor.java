package com.idr.navigator.engine;

import org.ejml.simple.SimpleMatrix;

public final class AiSpeedAdvisor implements FilterAdvisor {

    private final Eskf f;
    private double speed, trust;
    private long time;
    private boolean pending;

    public AiSpeedAdvisor(Eskf f) {
        this.f = f;
    }

    public void estimate(long t, double speed, double confidence, boolean placeholder) {
        this.time = t;
        this.speed = speed;
        this.trust = placeholder ? 0 : Math.min(.35, confidence * .35);
        pending = true;
    }

    public Measurement provide(long t) {
        if (
            !pending ||
            t - time > 2_000_000_000L ||
            trust == 0 ||
            !Double.isFinite(speed) ||
            speed < 0 ||
            speed > 80
        ) return null;
        pending = false;
        double mag = f.speed();
        if (mag < .5) return null;
        SimpleMatrix h = new SimpleMatrix(1, 15);
        h.set(0, 3, f.v[0] / mag);
        h.set(0, 4, f.v[1] / mag);
        return new Measurement(
            new SimpleMatrix(1, 1, true, new double[] { speed - mag }),
            h,
            SimpleMatrix.identity(1).scale(9)
        );
    }

    public double trustScore() {
        return trust;
    }
}
