package com.idr.navigator.plugins;

import android.content.SharedPreferences;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.idr.navigator.engine.*;
import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import org.tensorflow.lite.Interpreter;

@CapacitorPlugin(name = "ModelPlugin")
public final class ModelPlugin extends Plugin {

    @PluginMethod
    public void checkForUpdate(PluginCall call) {
        JSArray models = new JSArray();
        SharedPreferences p = getContext().getSharedPreferences("models", 0);
        org.json.JSONObject bundle = new org.json.JSONObject();
        try (InputStream in = getContext().getAssets().open("models/manifest.json")) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096]; int n;
            while ((n = in.read(buffer)) != -1) bytes.write(buffer, 0, n);
            bundle = new org.json.JSONObject(new String(bytes.toByteArray(), java.nio.charset.StandardCharsets.UTF_8));
        } catch (Exception e) { call.reject("Cannot read model manifest", e); return; }
        for (String name : TfliteModels.NAMES) {
            JSObject m = new JSObject();
            m.put("name", name);
            String version = p.getString(name + ".version", "0.0.0");
            boolean oldBundle = version.equals("0.0.0");
            org.json.JSONObject entry=new org.json.JSONObject();
            org.json.JSONArray entries=bundle.optJSONArray("models");
            for(int i=0;entries!=null&&i<entries.length();i++) {
                org.json.JSONObject e=entries.optJSONObject(i);
                if(e!=null&&name.equals(e.optString("name")))entry=e;
            }
            m.put("version", oldBundle ? entry.optString("version", "0.0.0") : version);
            m.put("placeholder", oldBundle ? entry.optBoolean("placeholder",true) : p.getBoolean(name + ".placeholder", true));
            m.put("validated", p.getBoolean(name + ".validated", false));
            models.put(m);
        }
        JSObject result = new JSObject();
        result.put("models", models);
        call.resolve(result);
    }

    // Internet transfer stays in Axios/JS. Native validates and atomically installs the staged binary.
    @PluginMethod
    public void downloadModel(PluginCall call) {
        String name = call.getString("name", ""),
            path = call.getString("path", ""),
            version = call.getString("version", ""),
            sha = call.getString("sha256", "");
        if (!java.util.Arrays.asList(TfliteModels.NAMES).contains(name)) {
            call.reject("Unknown model");
            return;
        }
        getBridge().execute(() -> {
            try {
                if(SensorCaptureService.instance!=null)throw new IOException("Stop tracking before installing model updates");
                String current=getContext().getSharedPreferences("models",0).getString(name+".version","0.0.0");
                if(ModelVersion.compare(version,current)<0)throw new IOException("Older model versions cannot replace the installed model");
                File source = new File(java.net.URI.create(path)).getCanonicalFile();
                if (
                    !source
                        .toPath()
                        .startsWith(getContext().getCacheDir().getCanonicalFile().toPath()) ||
                    source.length() > 100 * 1024 * 1024
                ) throw new IOException("Invalid staged model");
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                try (InputStream in = new FileInputStream(source)) {
                    byte[] b = new byte[65536];
                    int n;
                    while ((n = in.read(b)) != -1) digest.update(b, 0, n);
                }
                StringBuilder hash = new StringBuilder();
                for (byte b : digest.digest()) hash.append(String.format("%02x", b));
                if (!hash.toString().equals(sha)) throw new IOException("Model checksum mismatch");
                File dir = new File(getContext().getFilesDir(), "models");
                dir.mkdirs();
                File stage = new File(dir, name + ".staged");
                Files.copy(source.toPath(), stage.toPath(), StandardCopyOption.REPLACE_EXISTING);
                SensorCaptureService service = SensorCaptureService.instance;
                if (service != null && service.models != null) service.models.reload(name, stage);
                else {
                    try (Interpreter validated = TfliteModels.openValidated(stage, name)) {
                    }
                    Files.move(
                        stage.toPath(),
                        new File(dir, name + ".tflite").toPath(),
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE
                    );
                }
                getContext()
                    .getSharedPreferences("models", 0)
                    .edit()
                    .putString(name + ".version", version)
                    .putBoolean(name + ".placeholder", call.getBoolean("placeholder", true))
                    .putBoolean(name + ".validated", call.getBoolean("validated", false))
                    .apply();
                source.delete();
                call.resolve();
            } catch (Exception e) {
                call.reject(e.getMessage());
            }
        });
    }
}
