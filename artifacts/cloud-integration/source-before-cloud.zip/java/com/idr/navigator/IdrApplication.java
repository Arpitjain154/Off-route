package com.idr.navigator;

public final class IdrApplication extends android.app.Application {
    @Override public void onCreate() {
        super.onCreate();
        com.idr.navigator.engine.EngineDiagnostics.install(this);
    }
}
